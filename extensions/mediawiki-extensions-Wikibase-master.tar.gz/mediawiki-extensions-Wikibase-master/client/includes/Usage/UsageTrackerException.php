<?php

namespace Wikibase\Client\Usage;

use Exception;

/**
 * @license GPL-2.0-or-later
 * @author Daniel Kinzler
 */
class UsageTrackerException extends Exception {

}
