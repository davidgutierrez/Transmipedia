/*
 * JavaScript for WikiEditor Publish module
 */
jQuery( function ( $ ) {
	// Add publish module
	$( '#wpTextbox1' ).wikiEditor( 'addModule', 'publish' );
} );
