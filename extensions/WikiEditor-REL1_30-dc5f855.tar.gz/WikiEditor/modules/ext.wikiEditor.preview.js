/*
 * JavaScript for WikiEditor Preview module
 */
jQuery( function ( $ ) {
	// Add preview module
	$( 'textarea#wpTextbox1' ).wikiEditor( 'addModule', 'preview' );
} );
